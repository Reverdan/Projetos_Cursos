package com.dio.santander.bankline.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BanklineApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
